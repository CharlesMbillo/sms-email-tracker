export interface Transaction {
  id: string;
  amount: number;
  description: string;
  date: Date;
  type: 'debit' | 'credit';
  category: string;
  source: 'sms' | 'email';
  merchant?: string;
  account?: string;
  balance?: number;
}

export interface ParsedSMS {
  sender: string;
  message: string;
  timestamp: Date;
  transaction?: Transaction;
}

export interface GoogleSheetsConfig {
  spreadsheetId: string;
  credentials: any;
  sheetName: string;
}