import { Transaction } from '@/types/transaction';
import * as SecureStore from 'expo-secure-store';

export class GoogleSheetsService {
  private static instance: GoogleSheetsService;
  private spreadsheetId: string | null = null;
  private apiKey: string | null = null;

  static getInstance(): GoogleSheetsService {
    if (!GoogleSheetsService.instance) {
      GoogleSheetsService.instance = new GoogleSheetsService();
    }
    return GoogleSheetsService.instance;
  }

  async initialize() {
    try {
      this.spreadsheetId = await SecureStore.getItemAsync('SPREADSHEET_ID');
      this.apiKey = await SecureStore.getItemAsync('GOOGLE_SHEETS_API_KEY');
    } catch (error) {
      console.error('Error initializing Google Sheets service:', error);
    }
  }

  async setCredentials(spreadsheetId: string, apiKey: string) {
    try {
      await SecureStore.setItemAsync('SPREADSHEET_ID', spreadsheetId);
      await SecureStore.setItemAsync('GOOGLE_SHEETS_API_KEY', apiKey);
      this.spreadsheetId = spreadsheetId;
      this.apiKey = apiKey;
    } catch (error) {
      console.error('Error saving credentials:', error);
      throw error;
    }
  }

  async uploadTransaction(transaction: Transaction): Promise<boolean> {
    if (!this.spreadsheetId || !this.apiKey) {
      throw new Error('Google Sheets not configured');
    }

    try {
      const row = [
        transaction.date.toISOString(),
        transaction.description,
        transaction.amount,
        transaction.type,
        transaction.category,
        transaction.merchant || '',
        transaction.account || '',
        transaction.balance || '',
        transaction.source
      ];

      // Use Google Sheets API to append the row
      const response = await fetch(
        `https://sheets.googleapis.com/v4/spreadsheets/${this.spreadsheetId}/values/Transactions:append?valueInputOption=RAW&key=${this.apiKey}`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            values: [row]
          })
        }
      );

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      return true;
    } catch (error) {
      console.error('Error uploading to Google Sheets:', error);
      return false;
    }
  }

  async uploadTransactionsBatch(transactions: Transaction[]): Promise<number> {
    if (!this.spreadsheetId || !this.apiKey) {
      throw new Error('Google Sheets not configured');
    }

    try {
      const rows = transactions.map(transaction => [
        transaction.date.toISOString(),
        transaction.description,
        transaction.amount,
        transaction.type,
        transaction.category,
        transaction.merchant || '',
        transaction.account || '',
        transaction.balance || '',
        transaction.source
      ]);

      const response = await fetch(
        `https://sheets.googleapis.com/v4/spreadsheets/${this.spreadsheetId}/values/Transactions:append?valueInputOption=RAW&key=${this.apiKey}`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            values: rows
          })
        }
      );

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      return transactions.length;
    } catch (error) {
      console.error('Error uploading batch to Google Sheets:', error);
      return 0;
    }
  }

  async createSheetHeaders(): Promise<boolean> {
    if (!this.spreadsheetId || !this.apiKey) {
      throw new Error('Google Sheets not configured');
    }

    try {
      const headers = [
        'Date', 'Description', 'Amount', 'Type', 'Category', 
        'Merchant', 'Account', 'Balance', 'Source'
      ];

      const response = await fetch(
        `https://sheets.googleapis.com/v4/spreadsheets/${this.spreadsheetId}/values/Transactions!A1:I1?valueInputOption=RAW&key=${this.apiKey}`,
        {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            values: [headers]
          })
        }
      );

      return response.ok;
    } catch (error) {
      console.error('Error creating sheet headers:', error);
      return false;
    }
  }
}