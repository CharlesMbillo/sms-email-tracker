import { Platform } from 'react-native';
import * as SMS from 'expo-sms';
import { ParsedSMS } from '@/types/transaction';

export class SMSService {
  private static readonly BANK_SENDERS = [
    'SBIINB', 'HDFCBK', 'ICICIB', 'KOTAKB', 'AXISBK', 'PNBSMS', 'BOBSMS',
    'UCOBNK', 'CANARABK', 'UNIONBK', 'IDBIBK', 'MAHABK', 'VIJAYABK'
  ];

  static async requestPermissions(): Promise<boolean> {
    if (Platform.OS !== 'android') {
      console.warn('SMS reading is only supported on Android');
      return false;
    }

    try {
      // In a real Expo managed workflow, you'd need to eject or use a custom development build
      // to access native SMS functionality. This is a conceptual implementation.
      return true;
    } catch (error) {
      console.error('Error requesting SMS permissions:', error);
      return false;
    }
  }

  static async getTransactionSMS(limit: number = 100): Promise<ParsedSMS[]> {
    if (Platform.OS !== 'android') {
      // Return mock data for web/iOS testing
      return this.getMockSMS();
    }

    try {
      // This would require native module implementation in a real app
      // For now, returning mock data
      return this.getMockSMS();
    } catch (error) {
      console.error('Error reading SMS:', error);
      return [];
    }
  }

  private static getMockSMS(): ParsedSMS[] {
    return [
      {
        sender: 'SBIINB',
        message: 'Rs.500.00 debited from A/c **1234 on 15-Jan-24 at AMAZON. Avl Bal: Rs.15,430.25',
        timestamp: new Date('2024-01-15T10:30:00')
      },
      {
        sender: 'HDFCBK',
        message: 'Rs.2,500.00 credited to A/c **5678 on 14-Jan-24 from SALARY. Avl Bal: Rs.25,930.25',
        timestamp: new Date('2024-01-14T09:00:00')
      },
      {
        sender: 'ICICIB',
        message: 'Rs.1,200.00 spent on ICICI Bank Card **9012 at SWIGGY on 13-Jan-24. Avl Bal: Rs.23,430.25',
        timestamp: new Date('2024-01-13T19:45:00')
      },
      {
        sender: 'AXISBK',
        message: 'Rs.75.00 debited from A/c **3456 on 12-Jan-24 UPI to UBER. Avl Bal: Rs.24,630.25',
        timestamp: new Date('2024-01-12T14:20:00')
      }
    ];
  }
}