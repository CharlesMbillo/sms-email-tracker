import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Shield } from 'lucide-react-native';
import PermissionCard from '@/components/PermissionCard';
import { SMSService } from '@/services/smsService';

export default function PermissionsScreen() {
  const [smsPermission, setSmsPermission] = useState(false);
  const [emailPermission, setEmailPermission] = useState(false);

  useEffect(() => {
    checkPermissions();
  }, []);

  const checkPermissions = async () => {
    // Check current permission status
    // This would be implemented with proper native modules
    setSmsPermission(false); // Mock values
    setEmailPermission(false);
  };

  const requestSMSPermission = async () => {
    try {
      const granted = await SMSService.requestPermissions();
      setSmsPermission(granted);
      
      if (granted) {
        Alert.alert(
          'Permission Granted',
          'SMS access has been granted. The app can now read your transaction messages.',
          [{ text: 'OK' }]
        );
      } else {
        Alert.alert(
          'Permission Denied',
          'SMS access is required to automatically detect transactions. Please grant permission in device settings.',
          [{ text: 'OK' }]
        );
      }
    } catch (error) {
      console.error('Error requesting SMS permission:', error);
      Alert.alert('Error', 'Failed to request SMS permission');
    }
  };

  const requestEmailPermission = async () => {
    // For demonstration - email integration would require OAuth
    Alert.alert(
      'Email Integration',
      'Email integration requires Gmail API setup. Please configure OAuth credentials in settings.',
      [{ text: 'OK' }]
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Shield size={32} color="#3B82F6" />
        <Text style={styles.title}>Permissions</Text>
        <Text style={styles.subtitle}>
          Grant permissions to automatically track your transactions
        </Text>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <PermissionCard
          type="sms"
          granted={smsPermission}
          onRequest={requestSMSPermission}
        />
        
        <PermissionCard
          type="email"
          granted={emailPermission}
          onRequest={requestEmailPermission}
        />

        <View style={styles.infoCard}>
          <Text style={styles.infoTitle}>Privacy & Security</Text>
          <Text style={styles.infoText}>
            • All data is processed locally on your device{'\n'}
            • No sensitive information is stored on external servers{'\n'}
            • Transaction data is only uploaded to your Google Sheets{'\n'}
            • You can revoke permissions at any time in device settings
          </Text>
        </View>

        <View style={styles.requirementsCard}>
          <Text style={styles.requirementsTitle}>Technical Requirements</Text>
          <Text style={styles.requirementsText}>
            <Text style={styles.bold}>For SMS Reading:</Text>{'\n'}
            • Android device (iOS not supported){'\n'}
            • Expo development build or ejected app{'\n'}
            • READ_SMS permission{'\n\n'}
            
            <Text style={styles.bold}>For Email Reading:</Text>{'\n'}
            • Gmail API credentials{'\n'}
            • OAuth 2.0 setup{'\n'}
            • Internet connection
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 24,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: '#1F2937',
    marginTop: 8,
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    color: '#6B7280',
    textAlign: 'center',
    lineHeight: 22,
  },
  content: {
    flex: 1,
    paddingTop: 16,
  },
  infoCard: {
    backgroundColor: '#EBF8FF',
    borderRadius: 12,
    padding: 20,
    marginHorizontal: 16,
    marginVertical: 8,
    borderWidth: 1,
    borderColor: '#3B82F6',
  },
  infoTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1E40AF',
    marginBottom: 8,
  },
  infoText: {
    fontSize: 14,
    color: '#1E40AF',
    lineHeight: 20,
  },
  requirementsCard: {
    backgroundColor: '#FEF3C7',
    borderRadius: 12,
    padding: 20,
    marginHorizontal: 16,
    marginVertical: 8,
    borderWidth: 1,
    borderColor: '#F59E0B',
  },
  requirementsTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#92400E',
    marginBottom: 8,
  },
  requirementsText: {
    fontSize: 14,
    color: '#92400E',
    lineHeight: 20,
  },
  bold: {
    fontWeight: '600',
  },
});