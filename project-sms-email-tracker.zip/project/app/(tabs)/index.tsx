import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, RefreshControl, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { RefreshCw, Upload } from 'lucide-react-native';
import TransactionCard from '@/components/TransactionCard';
import { Transaction } from '@/types/transaction';
import { SMSService } from '@/services/smsService';
import { TransactionParser } from '@/utils/transactionParser';
import { GoogleSheetsService } from '@/services/googleSheetsService';

export default function TransactionsScreen() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [refreshing, setRefreshing] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [lastSync, setLastSync] = useState<Date | null>(null);

  useEffect(() => {
    loadTransactions();
    GoogleSheetsService.getInstance().initialize();
  }, []);

  const loadTransactions = async () => {
    try {
      const smsMessages = await SMSService.getTransactionSMS();
      const parsedTransactions = smsMessages
        .map(sms => TransactionParser.parseSMS(sms))
        .filter((t): t is Transaction => t !== null)
        .sort((a, b) => b.date.getTime() - a.date.getTime());
      
      setTransactions(parsedTransactions);
    } catch (error) {
      console.error('Error loading transactions:', error);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadTransactions();
    setRefreshing(false);
  };

  const uploadToSheets = async () => {
    if (transactions.length === 0) return;
    
    setUploading(true);
    try {
      const sheetsService = GoogleSheetsService.getInstance();
      const uploaded = await sheetsService.uploadTransactionsBatch(transactions);
      
      if (uploaded > 0) {
        setLastSync(new Date());
        console.log(`Successfully uploaded ${uploaded} transactions`);
      }
    } catch (error) {
      console.error('Error uploading to Google Sheets:', error);
    } finally {
      setUploading(false);
    }
  };

  const renderTransaction = ({ item }: { item: Transaction }) => (
    <TransactionCard transaction={item} />
  );

  const totalIncome = transactions
    .filter(t => t.type === 'credit')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalExpenses = transactions
    .filter(t => t.type === 'debit')
    .reduce((sum, t) => sum + t.amount, 0);

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Transactions</Text>
        <View style={styles.headerButtons}>
          <TouchableOpacity 
            style={styles.syncButton} 
            onPress={uploadToSheets}
            disabled={uploading}
          >
            <Upload size={20} color="#fff" />
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.summaryContainer}>
        <View style={styles.summaryCard}>
          <Text style={styles.summaryLabel}>Income</Text>
          <Text style={[styles.summaryAmount, styles.incomeAmount]}>
            +₹{totalIncome.toFixed(2)}
          </Text>
        </View>
        <View style={styles.summaryCard}>
          <Text style={styles.summaryLabel}>Expenses</Text>
          <Text style={[styles.summaryAmount, styles.expenseAmount]}>
            -₹{totalExpenses.toFixed(2)}
          </Text>
        </View>
      </View>

      {lastSync && (
        <Text style={styles.syncStatus}>
          Last synced: {lastSync.toLocaleString()}
        </Text>
      )}

      <FlatList
        data={transactions}
        renderItem={renderTransaction}
        keyExtractor={(item) => item.id}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
        contentContainerStyle={styles.listContainer}
        showsVerticalScrollIndicator={false}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#fff',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: '#1F2937',
  },
  headerButtons: {
    flexDirection: 'row',
  },
  syncButton: {
    backgroundColor: '#3B82F6',
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  summaryContainer: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingVertical: 16,
    gap: 12,
  },
  summaryCard: {
    flex: 1,
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  summaryLabel: {
    fontSize: 14,
    color: '#6B7280',
    marginBottom: 4,
  },
  summaryAmount: {
    fontSize: 20,
    fontWeight: '700',
  },
  incomeAmount: {
    color: '#10B981',
  },
  expenseAmount: {
    color: '#EF4444',
  },
  syncStatus: {
    fontSize: 12,
    color: '#6B7280',
    textAlign: 'center',
    marginBottom: 8,
  },
  listContainer: {
    paddingBottom: 20,
  },
});