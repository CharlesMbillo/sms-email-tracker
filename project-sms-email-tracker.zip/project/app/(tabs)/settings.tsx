import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TextInput, TouchableOpacity, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Settings as SettingsIcon, Save, TestTube, FileSpreadsheet } from 'lucide-react-native';
import { GoogleSheetsService } from '@/services/googleSheetsService';

export default function SettingsScreen() {
  const [spreadsheetId, setSpreadsheetId] = useState('');
  const [apiKey, setApiKey] = useState('');
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    // Load existing settings if any
    // This would retrieve from SecureStore in a real implementation
  };

  const saveSettings = async () => {
    if (!spreadsheetId.trim() || !apiKey.trim()) {
      Alert.alert('Error', 'Please fill in both Spreadsheet ID and API Key');
      return;
    }

    setSaving(true);
    try {
      const sheetsService = GoogleSheetsService.getInstance();
      await sheetsService.setCredentials(spreadsheetId.trim(), apiKey.trim());
      
      Alert.alert(
        'Settings Saved',
        'Google Sheets configuration has been saved successfully',
        [{ text: 'OK' }]
      );
    } catch (error) {
      console.error('Error saving settings:', error);
      Alert.alert('Error', 'Failed to save settings. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const testConnection = async () => {
    if (!spreadsheetId.trim() || !apiKey.trim()) {
      Alert.alert('Error', 'Please save your settings first');
      return;
    }

    setTesting(true);
    try {
      const sheetsService = GoogleSheetsService.getInstance();
      const success = await sheetsService.createSheetHeaders();
      
      if (success) {
        Alert.alert(
          'Connection Successful',
          'Successfully connected to your Google Sheet and created headers',
          [{ text: 'OK' }]
        );
      } else {
        Alert.alert('Connection Failed', 'Unable to connect to Google Sheets. Please check your credentials.');
      }
    } catch (error) {
      console.error('Error testing connection:', error);
      Alert.alert('Connection Failed', 'Unable to connect to Google Sheets. Please check your credentials.');
    } finally {
      setTesting(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <SettingsIcon size={32} color="#3B82F6" />
        <Text style={styles.title}>Settings</Text>
        <Text style={styles.subtitle}>
          Configure Google Sheets integration
        </Text>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Google Sheets Configuration</Text>
          
          <View style={styles.inputContainer}>
            <Text style={styles.label}>Spreadsheet ID</Text>
            <TextInput
              style={styles.input}
              value={spreadsheetId}
              onChangeText={setSpreadsheetId}
              placeholder="1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgvE2upms"
              placeholderTextColor="#9CA3AF"
              autoCapitalize="none"
              autoCorrect={false}
            />
            <Text style={styles.hint}>
              Found in the URL of your Google Sheet between /d/ and /edit
            </Text>
          </View>

          <View style={styles.inputContainer}>
            <Text style={styles.label}>API Key</Text>
            <TextInput
              style={styles.input}
              value={apiKey}
              onChangeText={setApiKey}
              placeholder="AIzaSyD..."
              placeholderTextColor="#9CA3AF"
              secureTextEntry
              autoCapitalize="none"
              autoCorrect={false}
            />
            <Text style={styles.hint}>
              Your Google Sheets API key from Google Cloud Console
            </Text>
          </View>

          <View style={styles.buttonContainer}>
            <TouchableOpacity
              style={[styles.button, styles.saveButton]}
              onPress={saveSettings}
              disabled={saving}
            >
              <Save size={20} color="#fff" />
              <Text style={styles.buttonText}>
                {saving ? 'Saving...' : 'Save Settings'}
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.button, styles.testButton]}
              onPress={testConnection}
              disabled={testing}
            >
              <TestTube size={20} color="#3B82F6" />
              <Text style={[styles.buttonText, styles.testButtonText]}>
                {testing ? 'Testing...' : 'Test Connection'}
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.instructionsCard}>
          <FileSpreadsheet size={24} color="#059669" />
          <Text style={styles.instructionsTitle}>Setup Instructions</Text>
          <Text style={styles.instructionsText}>
            1. Create a new Google Sheet or use an existing one{'\n'}
            2. Get the Spreadsheet ID from the URL{'\n'}
            3. Enable Google Sheets API in Google Cloud Console{'\n'}
            4. Create an API key with Sheets API access{'\n'}
            5. Make sure your sheet is publicly accessible or share with your service account
          </Text>
        </View>

        <View style={styles.warningCard}>
          <Text style={styles.warningTitle}>⚠️ Important Notes</Text>
          <Text style={styles.warningText}>
            • API keys are stored securely on your device{'\n'}
            • Ensure your Google Sheet has proper permissions{'\n'}
            • Test the connection before using the app{'\n'}
            • Data will be appended to a sheet named "Transactions"
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 24,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: '#1F2937',
    marginTop: 8,
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    color: '#6B7280',
    textAlign: 'center',
  },
  content: {
    flex: 1,
    paddingTop: 16,
  },
  section: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 20,
    marginHorizontal: 16,
    marginVertical: 8,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1F2937',
    marginBottom: 16,
  },
  inputContainer: {
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: '500',
    color: '#374151',
    marginBottom: 6,
  },
  input: {
    borderWidth: 1,
    borderColor: '#D1D5DB',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 16,
    backgroundColor: '#fff',
  },
  hint: {
    fontSize: 12,
    color: '#6B7280',
    marginTop: 4,
    lineHeight: 16,
  },
  buttonContainer: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 8,
  },
  button: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
  },
  saveButton: {
    backgroundColor: '#3B82F6',
  },
  testButton: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#3B82F6',
  },
  buttonText: {
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 8,
    color: '#fff',
  },
  testButtonText: {
    color: '#3B82F6',
  },
  instructionsCard: {
    backgroundColor: '#ECFDF5',
    borderRadius: 12,
    padding: 20,
    marginHorizontal: 16,
    marginVertical: 8,
    borderWidth: 1,
    borderColor: '#10B981',
  },
  instructionsTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#059669',
    marginTop: 8,
    marginBottom: 8,
  },
  instructionsText: {
    fontSize: 14,
    color: '#047857',
    lineHeight: 20,
  },
  warningCard: {
    backgroundColor: '#FEF2F2',
    borderRadius: 12,
    padding: 20,
    marginHorizontal: 16,
    marginVertical: 8,
    borderWidth: 1,
    borderColor: '#EF4444',
  },
  warningTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#DC2626',
    marginBottom: 8,
  },
  warningText: {
    fontSize: 14,
    color: '#B91C1C',
    lineHeight: 20,
  },
});