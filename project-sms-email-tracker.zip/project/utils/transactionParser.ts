import { Transaction, ParsedSMS } from '@/types/transaction';

export class TransactionParser {
  // Common bank SMS patterns
  private static readonly PATTERNS = {
    // Amount patterns
    amount: /(?:Rs\.?\s*|INR\s*|₹\s*)(\d+(?:,\d{3})*(?:\.\d{2})?)/i,
    
    // Transaction type indicators
    debit: /(?:debited|spent|withdrawn|paid|purchase|debit)/i,
    credit: /(?:credited|received|deposited|refund|credit)/i,
    
    // Merchant/description
    merchant: /(?:at\s+|to\s+|from\s+)([A-Z0-9\s]{3,30})/i,
    
    // Account number (last 4 digits)
    account: /(?:a\/c|account|card).*?(\d{4})/i,
    
    // Balance
    balance: /(?:balance|bal).*?(?:Rs\.?\s*|₹\s*)(\d+(?:,\d{3})*(?:\.\d{2})?)/i,
    
    // Date patterns
    date: /(\d{1,2}[-\/]\d{1,2}[-\/]\d{2,4})|(\d{1,2}\s+(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)\s+\d{2,4})/i
  };

  static parseSMS(sms: ParsedSMS): Transaction | null {
    const { message, timestamp, sender } = sms;
    
    try {
      // Extract amount
      const amountMatch = message.match(this.PATTERNS.amount);
      if (!amountMatch) return null;
      
      const amount = parseFloat(amountMatch[1].replace(/,/g, ''));
      
      // Determine transaction type
      const isDebit = this.PATTERNS.debit.test(message);
      const isCredit = this.PATTERNS.credit.test(message);
      
      if (!isDebit && !isCredit) return null;
      
      // Extract merchant/description
      const merchantMatch = message.match(this.PATTERNS.merchant);
      const merchant = merchantMatch ? merchantMatch[1].trim() : '';
      
      // Extract account
      const accountMatch = message.match(this.PATTERNS.account);
      const account = accountMatch ? `****${accountMatch[1]}` : '';
      
      // Extract balance
      const balanceMatch = message.match(this.PATTERNS.balance);
      const balance = balanceMatch ? parseFloat(balanceMatch[1].replace(/,/g, '')) : undefined;
      
      // Generate transaction
      const transaction: Transaction = {
        id: `${timestamp.getTime()}_${sender}`,
        amount,
        description: merchant || this.extractDescription(message),
        date: timestamp,
        type: isDebit ? 'debit' : 'credit',
        category: this.categorizeTransaction(message, merchant),
        source: 'sms',
        merchant,
        account,
        balance
      };
      
      return transaction;
    } catch (error) {
      console.error('Error parsing SMS:', error);
      return null;
    }
  }
  
  private static extractDescription(message: string): string {
    // Clean up the message to create a readable description
    return message
      .replace(/Rs\.?\s*\d+(?:,\d{3})*(?:\.\d{2})?/gi, '')
      .replace(/₹\s*\d+(?:,\d{3})*(?:\.\d{2})?/gi, '')
      .replace(/\b(?:debited|credited|from|to|at|on)\b/gi, '')
      .replace(/\s+/g, ' ')
      .trim()
      .substring(0, 100);
  }
  
  private static categorizeTransaction(message: string, merchant: string): string {
    const text = (message + ' ' + merchant).toLowerCase();
    
    if (/fuel|petrol|diesel|gas|hp|bharat|ioc/i.test(text)) return 'Fuel';
    if (/grocery|supermarket|mart|store|shop/i.test(text)) return 'Groceries';
    if (/restaurant|cafe|food|zomato|swiggy|uber.*eats/i.test(text)) return 'Food & Dining';
    if (/medical|hospital|pharmacy|medicine|health/i.test(text)) return 'Healthcare';
    if (/transport|taxi|uber|ola|metro|bus|train/i.test(text)) return 'Transportation';
    if (/entertainment|movie|cinema|netflix|amazon.*prime/i.test(text)) return 'Entertainment';
    if (/utility|electricity|water|gas|internet|mobile|recharge/i.test(text)) return 'Utilities';
    if (/atm|bank|transfer|upi/i.test(text)) return 'Banking';
    if (/salary|income|refund/i.test(text)) return 'Income';
    
    return 'Others';
  }
}