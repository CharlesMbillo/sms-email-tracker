import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Shield, MessageSquare, Mail } from 'lucide-react-native';

interface PermissionCardProps {
  type: 'sms' | 'email';
  granted: boolean;
  onRequest: () => void;
}

export default function PermissionCard({ type, granted, onRequest }: PermissionCardProps) {
  const config = {
    sms: {
      icon: MessageSquare,
      title: 'SMS Access',
      description: 'Read transaction messages from banks and payment apps',
      reason: 'We need to read SMS messages to automatically detect and parse your transaction notifications.'
    },
    email: {
      icon: Mail,
      title: 'Email Access',
      description: 'Read transaction emails from banks and payment services',
      reason: 'We need to access your emails to detect transaction notifications and statements.'
    }
  };

  const { icon: Icon, title, description, reason } = config[type];

  return (
    <View style={styles.card}>
      <View style={styles.header}>
        <View style={[styles.iconContainer, granted ? styles.grantedIcon : styles.pendingIcon]}>
          <Icon size={24} color="#fff" />
        </View>
        <View style={styles.titleContainer}>
          <Text style={styles.title}>{title}</Text>
          <Text style={styles.description}>{description}</Text>
        </View>
      </View>
      
      <Text style={styles.reason}>{reason}</Text>
      
      <TouchableOpacity
        style={[styles.button, granted ? styles.grantedButton : styles.requestButton]}
        onPress={onRequest}
        disabled={granted}
      >
        <Shield size={16} color={granted ? '#10B981' : '#fff'} />
        <Text style={[styles.buttonText, granted ? styles.grantedButtonText : styles.requestButtonText]}>
          {granted ? 'Permission Granted' : 'Grant Permission'}
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 20,
    marginHorizontal: 16,
    marginVertical: 8,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  iconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  pendingIcon: {
    backgroundColor: '#F59E0B',
  },
  grantedIcon: {
    backgroundColor: '#10B981',
  },
  titleContainer: {
    flex: 1,
  },
  title: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1F2937',
    marginBottom: 4,
  },
  description: {
    fontSize: 14,
    color: '#6B7280',
  },
  reason: {
    fontSize: 14,
    color: '#4B5563',
    lineHeight: 20,
    marginBottom: 16,
  },
  button: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
  },
  requestButton: {
    backgroundColor: '#3B82F6',
  },
  grantedButton: {
    backgroundColor: '#F0FDF4',
    borderWidth: 1,
    borderColor: '#10B981',
  },
  buttonText: {
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 8,
  },
  requestButtonText: {
    color: '#fff',
  },
  grantedButtonText: {
    color: '#10B981',
  },
});