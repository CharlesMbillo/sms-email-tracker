import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Transaction } from '@/types/transaction';
import { ArrowUpRight, ArrowDownLeft } from 'lucide-react-native';

interface TransactionCardProps {
  transaction: Transaction;
}

export default function TransactionCard({ transaction }: TransactionCardProps) {
  const isDebit = transaction.type === 'debit';
  
  return (
    <View style={styles.card}>
      <View style={styles.header}>
        <View style={[styles.iconContainer, isDebit ? styles.debitIcon : styles.creditIcon]}>
          {isDebit ? (
            <ArrowUpRight size={20} color="#fff" />
          ) : (
            <ArrowDownLeft size={20} color="#fff" />
          )}
        </View>
        <View style={styles.titleContainer}>
          <Text style={styles.description} numberOfLines={1}>
            {transaction.description}
          </Text>
          <Text style={styles.category}>{transaction.category}</Text>
        </View>
        <View style={styles.amountContainer}>
          <Text style={[styles.amount, isDebit ? styles.debitAmount : styles.creditAmount]}>
            {isDebit ? '-' : '+'} ₹{transaction.amount.toFixed(2)}
          </Text>
          <Text style={styles.date}>
            {transaction.date.toLocaleDateString()}
          </Text>
        </View>
      </View>
      
      {transaction.merchant && (
        <Text style={styles.merchant}>at {transaction.merchant}</Text>
      )}
      
      <View style={styles.footer}>
        <Text style={styles.account}>{transaction.account}</Text>
        <Text style={styles.source}>{transaction.source.toUpperCase()}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginHorizontal: 16,
    marginVertical: 6,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  debitIcon: {
    backgroundColor: '#EF4444',
  },
  creditIcon: {
    backgroundColor: '#10B981',
  },
  titleContainer: {
    flex: 1,
  },
  description: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1F2937',
    marginBottom: 2,
  },
  category: {
    fontSize: 14,
    color: '#6B7280',
  },
  amountContainer: {
    alignItems: 'flex-end',
  },
  amount: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 2,
  },
  debitAmount: {
    color: '#EF4444',
  },
  creditAmount: {
    color: '#10B981',
  },
  date: {
    fontSize: 12,
    color: '#6B7280',
  },
  merchant: {
    fontSize: 14,
    color: '#4B5563',
    marginBottom: 8,
    marginLeft: 52,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 8,
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: '#F3F4F6',
  },
  account: {
    fontSize: 12,
    color: '#6B7280',
    fontFamily: 'monospace',
  },
  source: {
    fontSize: 10,
    color: '#9CA3AF',
    backgroundColor: '#F3F4F6',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
});